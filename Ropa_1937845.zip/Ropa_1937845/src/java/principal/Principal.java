/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

import Clases.Singleton;
import java.util.Scanner;

/**
 *
 * @author Coronado
 */
public class Principal {
        private static Scanner S = new Scanner(System.in);
        
        public static void main(String [] args){
        int opc;
        do{
            opc= menu();
            switch(opc){
                case 1:
                    System.out.print("Ingrese nombre del producto en venta: ");
                    String producto=S.nextLine();
                    System.out.print("Ingrese cantidad vendida: ");
                    int cant= Integer.parseInt(S.nextLine());
                    Singleton.getInstancia().agregarVenta(producto,cant);
                    break;
                case 2:
                    System.out.println(Singleton.getInstancia().toString());
                    break;
                case 3:
                    System.out.println("Cerrando programa.");
                    break;
                default:
                    System.out.println("Opcion invalida.");
                
            }
        }while(opc!=3);
        }
        
        private static int menu(){
            System.out.print(
                    "\nMENU DE OPCIONES"
                    +"\n1. Registrar nueva venta."
                    +"\n2. Consultar historial de venta."
                    +"\n3. Salir del programa."
                    +"\n Seleccione opcion:");
            return Integer.parseInt(S.nextLine());
        
        
        
        }
        }
        
        