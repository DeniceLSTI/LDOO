/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

import java.sql.Connection;
import java.sql.*;
/**
 *
 * @author Coronado
 */
public class Conexion {
    
    Connection cn;
    
    
    public Connection Conexion(){
    try{
        Class.forName("com.mysql.jdbc.Dirver");
        cn=DriverManager.getConnection("jdbc:mysql://localhost/sistema","root","coronado123");
        System.out.println("Se hizo la conexion existosa");
    }catch(Exception e){
        System.out.println(e.getMessage());
        }return cn;
    }
    
    Statement createStatement(){
        throw new UnsupportedOperationException("No soportado");
        
    }
    
    
    }

