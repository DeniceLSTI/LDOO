
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Rene
 */
@WebServlet(urlPatterns = {"/srvLog"})
public class srvLog extends HttpServlet{

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    InitialContext ctx;
    Conecta con;
    Statement stm;
    ResultSet rs;
    
    @Override
    public void init () throws ServletException {
        try {
            ctx = new InitialContext();
            con= new Conecta();
            stm = (Statement) con.getConexion();
            stm = con.createStatement();
        } catch (NamingException ex) {
            Logger.getLogger(srvLog.class.getName()).log(Level.SEVERE, null, ex);
        }
  }

    @Override
  public void destroy () {
    try {
      if (rs != null)
        rs.close();
      if (stm != null)
        stm.close();
      if (con != null)
        con.getConexion().close();
      if (ctx != null)
        ctx.close();
    }   
    catch (SQLException se) {
      System.out.println("SQLException: "+se.getMessage());
    }
    catch (NamingException ne) {
      System.out.println("NamingException: "+ne.getMessage());
    }
  }
   
    
   
    
    @Override
   protected void doGet(HttpServletRequest request,
                    HttpServletResponse response)throws ServletException, IOException
   {
        try {
            response.setContentType("text/html");
            rs = stm.executeQuery("select name from administradores where name='"+request.getParameter("Nombre")+"' and password='"+request.getParameter("Contrasena")+"'");
            PrintWriter html = response.getWriter();
            
            if(rs.next()){
                
                request.getSession().setAttribute("nombre", rs.getString("name"));
                response.sendRedirect("HOME.jsp");
            }else{
                html.println("<!doctype html>");
                html.println("<meta charset='utf-8'>");
                html.println("<title>Ejemplo Morgado</title>");
                html.println("</head>");
                html.println("<body>");
                html.println("<h1><CENTER>No has iniciado Sesion</CENTER></h1>");
                html.println("<h2>El usuario o la contraseña no existen</h2>");
                html.println("<form name='form1' method='post' action='index.jsp'>");
                html.println("<input type='submit' name='boton' id='btnR' value='Regresar'>");
                html.println("</form>");
                html.println("</body>");
                html.println("</html>");
                html.close(); 
            }} catch (SQLException ex) {
            Logger.getLogger(srvLog.class.getName()).log(Level.SEVERE, null, ex);
        }
      
      
  }
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
      doGet(request, response);
   }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}